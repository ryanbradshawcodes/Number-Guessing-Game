package com.ryanbradshawcodes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI implements ActionListener {

    static JFrame frame;
    static JButton tryAgainButton;
    static JButton submitButton;
    static JTextField userInput;
    static JLabel inputLabel;
    static JPanel panel;
    static JLabel inputResponse;

    static int minNum = 0;
    static int maxNum = 100;
    static int tries = 0;
    static int randomNum = (int) Math.floor(Math.random() * (maxNum - minNum + 1) + minNum);

    public static void main(String[] args) {

        //Setup
        frame = new JFrame();
        panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(75,200,75,200));
        panel.setLayout(new GridLayout(0,1));

        //Higher, lower, or you got it text
        inputResponse = new JLabel("");
        inputResponse.setBounds(170,70,150,25);
        frame.add(inputResponse);

        //Try again button
        tryAgainButton = new JButton("Try again");
        tryAgainButton.setBounds(5,120,100,25);
        tryAgainButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        inputResponse.setText("");
                        tries = 0;
                        randomNum = (int) Math.floor(Math.random() * (maxNum - minNum + 1) + minNum);
                    }
                }
        );
        frame.add(tryAgainButton);

        //Submit button
        submitButton = new JButton("Submit");
        submitButton.setBounds(270, 20, 80,25);
        submitButton.addActionListener(new GUI());
        frame.add(submitButton);

        //Text box to input guess
        userInput = new JTextField(20);
        userInput.setBounds(185,20,30,25);
        frame.add(userInput);

        //Text next to text box
        inputLabel = new JLabel("Enter your guess:");
        inputLabel.setBounds(40,20,100,25);
        frame.add(inputLabel);

        //Frame setup
        frame.setTitle("Number Guessing Game");
        frame.add(panel, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        int userGuess = Integer.parseInt(userInput.getText());
        userInput.setText("");

        if (userGuess < 0 || userGuess > 100) {
            inputResponse.setText("Invalid input, try again!");
        }

        else if (userGuess < randomNum) {
            tries++;
            inputResponse.setText("Higher!");
        }
        else if (userGuess > randomNum) {
            tries++;
            inputResponse.setText("Lower!");
        }
        else {
            tries++;
            inputResponse.setText("You got it in " + tries + " tries!");
        }
    }
}